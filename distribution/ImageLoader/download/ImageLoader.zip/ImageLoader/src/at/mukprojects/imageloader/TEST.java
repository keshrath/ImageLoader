package at.mukprojects.imageloader;

import java.util.Date;
import java.util.List;

import org.jinstagram.Instagram;
import org.jinstagram.entity.tags.TagMediaFeed;
import org.jinstagram.entity.users.feed.MediaFeedData;
import org.jinstagram.exceptions.InstagramException;

import at.mukprojects.imageloader.instagram.InstagramLoader;

public class TEST {

    public static void main(String[] args) throws InstagramException {
	Instagram instagram = new Instagram("1722917717.cbb3637.c9d399ea75b24dad9afe5f8b52e186db", "");
	//Instagram instagram = new Instagram("ae59c89f2393449e999698fa54b0a51e");
	
	String tagName = "nofilter";
	
    }

}
