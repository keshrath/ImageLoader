package at.mukprojects.imageloader.google;

import java.util.List;

import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.customsearch.Customsearch;
import com.google.api.services.customsearch.model.Result;
import com.google.api.services.customsearch.model.Search;

/**
 * Created by IntelliJ IDEA. User: Niraj Singh Date: 6/3/14 Time: 12:42 PM To
 * change this template use File | Settings | File Templates.
 */
public class Test2 {

    // api key
    final private String API_KEY = "AIzaSyCFunLCVbf8QAFvpOQOwXiE_Dht80wZqKU";
    // custom search engine ID
    final private String SEARCH_ENGINE_ID = "018120529865639172616:gn3bbggenh8";

    public static void main(String[] args) {

	Test2 gsc = new Test2();
	String searchKeyWord = "comic drawing";
	List<Result> resultList = gsc.getSearchResult(searchKeyWord);
	System.out.println(resultList.size());
	if (resultList != null && resultList.size() > 0) {
	    for (Result result : resultList) {
		System.out.println(result.getCacheId());
		System.out.println(result.getLabels());
		System.out.println(result.getTitle());
		System.out.println(result.getDisplayLink());
		System.out.println(result.getHtmlTitle());
		System.out.println(result.getFormattedUrl());
		System.out.println(result.getHtmlSnippet());
		System.out.println(result.getMime());
		System.out.println(result.getKind());
		System.out.println(result.getSnippet());
		System.out.println("----------------------------------------");
	    }
	}
    }

    public List<Result> getSearchResult(String keyword) {
	// Set up the HTTP transport and JSON factory
	HttpTransport httpTransport = new NetHttpTransport();
	JsonFactory jsonFactory = new JacksonFactory();

	Customsearch customsearch = new Customsearch(httpTransport, jsonFactory, null);
	
	List<Result> resultList = null;
	try {
	    Customsearch.Cse.List list = customsearch.cse().list(keyword);
	    list.setKey(API_KEY);
	    list.setCx(SEARCH_ENGINE_ID);
	    list.setSearchType("image");
	    // num results per page
	    // list.setNum(30L);

	    // for pagination
	    list.setStart(30L);
	    
	    System.out.println(list);
	    Search results = list.execute();
	    System.out.println(resultList);
	    resultList = results.getItems();
	    System.out.println(resultList);
	    
	} catch (Exception e) {
	    e.printStackTrace();
	}

	return resultList;

    }
}